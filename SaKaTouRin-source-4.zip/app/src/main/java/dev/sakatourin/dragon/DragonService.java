package dev.sakatourin.dragon;
import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;

public class DragonService extends Service {
 WindowManager wm;
 WindowManager.LayoutParams lp, bubbleLp;
 FrameLayout root;
 DragonView pet;
 android.animation.ValueAnimator modeAnimator;
 boolean working=false;
 float modeBlend=0;
 TextView bubble;
 int state=0, failures=0;
 Handler handler=new Handler(Looper.getMainLooper());
 volatile boolean alive=true;
 boolean bubbleAdded=false, requestRunning=false, frameScheduled=false;
 volatile HttpURLConnection connection;
 JSONObject data=new JSONObject();
 String status="未连接账号数据";
 long bounceStart=-1;
 int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 public IBinder onBind(Intent i){return null;}

 public void onCreate(){
  super.onCreate();
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
  nm.createNotificationChannel(new NotificationChannel("dragon","龙娘悬浮窗",NotificationManager.IMPORTANCE_LOW));
  PendingIntent pi=PendingIntent.getService(this,1,new Intent(this,DragonService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"dragon").setContentTitle("SaKaTouRin运行中")
   .setContentText("点击查看额度，拖动移动，长按切换打字")
   .setSmallIcon(android.R.drawable.ic_dialog_info)
   .addAction(new Notification.Action.Builder(null,"关闭",pi).build()).build();
  startForeground(1,n);
  try {data=new JSONObject(getSharedPreferences("config",0).getString("lastData","{}"));}
  catch(JSONException ignored){}
  if(data.length()>0)status="正在重连 · 上次数据";
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  root=new FrameLayout(this);
  try{pet=new DragonView(this);}catch(IOException e){stopSelf();return;}
  int width=pet.idleWidth,height=pet.imageHeight;
  root.addView(pet,new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.MATCH_PARENT));
  // No hidden bubble space belongs to this window. Outside touches reach the app below.
  int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
  lp=new WindowManager.LayoutParams(width,height,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);
  lp.gravity=Gravity.TOP|Gravity.LEFT;
  lp.x=getSharedPreferences("config",0).getInt("petX",dp(32));
  lp.y=getSharedPreferences("config",0).getInt("petY",dp(280));
  clampPosition();
  try{wm.addView(root,lp);}catch(RuntimeException e){stopSelf();return;}
  bubble=new TextView(this);bubble.setTextColor(Color.rgb(48,39,65));bubble.setTextSize(13);
  bubble.setIncludeFontPadding(false);bubble.setMinHeight(dp(92));bubble.setPadding(dp(16),dp(16),dp(16),dp(16));
  GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(19));bg.setStroke(dp(1),Color.rgb(238,231,245));bubble.setBackground(bg);
  bubbleLp=new WindowManager.LayoutParams(dp(200),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);
  bubbleLp.gravity=Gravity.TOP|Gravity.LEFT;
  bubble.setOnClickListener(v->cycle());
  pet.setOnTouchListener(new View.OnTouchListener(){
   float x,y;int ox,oy;boolean dragged,held;
   final Runnable hold=()->{held=true;toggleWorking();pet.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);};
   public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
    case MotionEvent.ACTION_DOWN:x=e.getRawX();y=e.getRawY();ox=lp.x;oy=lp.y;dragged=false;held=false;handler.postDelayed(hold,550);return true;
    case MotionEvent.ACTION_MOVE:
     if(held)return true;
     float dx=e.getRawX()-x,dy=e.getRawY()-y;
     if(Math.abs(dx)+Math.abs(dy)>dp(8)){dragged=true;handler.removeCallbacks(hold);}
     if(dragged){lp.x=ox+(int)dx;lp.y=oy+(int)dy;clampPosition();wm.updateViewLayout(root,lp);positionBubble();}return true;
    case MotionEvent.ACTION_UP:
     handler.removeCallbacks(hold);
     if(dragged)getSharedPreferences("config",0).edit().putInt("petX",lp.x).putInt("petY",lp.y).apply();
     else if(!held&&alive){v.performClick();cycle();}return true;
    case MotionEvent.ACTION_CANCEL:handler.removeCallbacks(hold);return true;
   }return false;}
  });
  handler.post(poll);
 }
 // Animate both artwork and compact window width around the same bottom center.
 void toggleWorking(){
  working=!working;
  if(modeAnimator!=null)modeAnimator.cancel();
  bounceStart=-1;pet.setScaleX(1);pet.setScaleY(1);
  pet.setTyping(false);
  final int center=lp.x+lp.width/2;
  modeAnimator=android.animation.ValueAnimator.ofFloat(modeBlend,working?1f:0f);
  modeAnimator.setDuration(340);
  modeAnimator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
  modeAnimator.addUpdateListener(a->{
   if(!alive)return;
   modeBlend=(float)a.getAnimatedValue();pet.setBlend(modeBlend);
   lp.width=pet.widthAt(modeBlend);lp.x=center-lp.width/2;clampPosition();
   wm.updateViewLayout(root,lp);positionBubble();
  });
  modeAnimator.addListener(new android.animation.AnimatorListenerAdapter(){
   boolean cancelled;
   public void onAnimationCancel(android.animation.Animator a){cancelled=true;}
   public void onAnimationEnd(android.animation.Animator a){if(!cancelled&&alive)pet.setTyping(working);}
  });
  modeAnimator.start();
 }
 void clampPosition(){
  android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getMetrics(m);
  lp.x=Math.max(0,Math.min(Math.max(0,m.widthPixels-lp.width),lp.x));
  lp.y=Math.max(0,Math.min(Math.max(0,m.heightPixels-lp.height),lp.y));
 }
 void positionBubble(){
  if(!bubbleAdded)return;
  android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getMetrics(m);
  bubble.measure(View.MeasureSpec.makeMeasureSpec(dp(200),View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(m.heightPixels,View.MeasureSpec.AT_MOST));
  bubbleLp.x=Math.max(0,Math.min(Math.max(0,m.widthPixels-dp(200)),lp.x+lp.width-dp(20)));
  int above=lp.y-bubble.getMeasuredHeight()-dp(6);
  bubbleLp.y=Math.max(0,Math.min(Math.max(0,m.heightPixels-bubble.getMeasuredHeight()),above>=0?above:lp.y+lp.height+dp(6)));
  wm.updateViewLayout(bubble,bubbleLp);
 }
 void showBubble(){
  if(!bubbleAdded){try{wm.addView(bubble,bubbleLp);bubbleAdded=true;}catch(RuntimeException ignored){return;}}
  positionBubble();
 }
 void hideBubble(){if(bubbleAdded){try{wm.removeView(bubble);}catch(RuntimeException ignored){}bubbleAdded=false;}}
 // Retain the click squash, anchored at the feet. No idle bobbing or vertical lift.
 final Choreographer.FrameCallback motionFrame=new Choreographer.FrameCallback(){public void doFrame(long now){
  frameScheduled=false;if(!alive||pet==null)return;
  float elapsed=(now-bounceStart)/600000000f;
  pet.setPivotX(pet.getWidth()*.5f);pet.setPivotY(pet.getHeight());
  if(elapsed<1){float q=HtmlMotion.bounceProgress(elapsed);pet.setScaleX(Math.min(1f,HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.X)));pet.setScaleY(Math.min(1f,HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.Y)));scheduleFrame();}
  else {pet.setScaleX(1);pet.setScaleY(1);bounceStart=-1;}
 }};
 void scheduleFrame(){if(!frameScheduled&&alive){frameScheduled=true;Choreographer.getInstance().postFrameCallback(motionFrame);}}
 void cycle(){bounceStart=System.nanoTime();scheduleFrame();state=(state+1)%4;render();}
 static String formatTokens(long tokens){if(tokens>=100000000L)return String.format(java.util.Locale.ROOT,"%.2f亿",tokens/100000000d);if(tokens>=10000L)return String.format(java.util.Locale.ROOT,"%.2f万",tokens/10000d);return String.format(java.util.Locale.ROOT,"%,d",tokens);}
 void render(){if(state==0){hideBubble();return;}String title=state==1?"五小时额度剩余":state==2?"本周额度剩余":"累计 Token";String value="未连接";String foot=status;if(data.has("lastUpdated")&&!data.isNull("lastUpdated")&&System.currentTimeMillis()/1000-data.optLong("lastUpdated")>150)foot="数据已过期 · 请检查 Termux";if(data.length()>0){if(state==3){if(!data.isNull("lifetimeTokens"))value=formatTokens(data.optLong("lifetimeTokens"));else value="暂无数据";}else{JSONObject w=data.optJSONObject(state==1?"fiveHour":"weekly");if(w!=null&&!w.isNull("remainingPercent")){value=String.format(java.util.Locale.getDefault(),"%.0f%%",w.optDouble("remainingPercent"));if(!data.optBoolean("stale",false)&&!foot.startsWith("数据已过期")&&!status.startsWith("连接中断")&&!status.startsWith("正在重连")&&!status.startsWith("本地服务")&&!status.equals("配对密钥不正确"))foot="Codex · "+w.optString("resetText",status);}else value="暂无数据";}}android.text.SpannableString text=new android.text.SpannableString(title+"\n"+value+"\n"+foot);
 int valueStart=title.length()+1,footStart=valueStart+value.length()+1;
 text.setSpan(new android.text.style.AbsoluteSizeSpan(13,true),0,title.length(),0);
 text.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(142,125,156)),0,title.length(),0);
 text.setSpan(new android.text.style.AbsoluteSizeSpan(23,true),valueStart,footStart-1,0);
 text.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),valueStart,footStart-1,0);
 text.setSpan(new android.text.style.AbsoluteSizeSpan(11,true),footStart,text.length(),0);
 text.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(156,144,164)),footStart,text.length(),0);
 bubble.setText(text);showBubble();}

 // Schedule after completion; never overlap requests. Reconnect rapidly before backing off.
 final Runnable poll=new Runnable(){public void run(){
  if(!alive||requestRunning)return;
  String u=getSharedPreferences("config",0).getString("url","http://127.0.0.1:8765/quota");
  String key=getSharedPreferences("config",0).getString("key","");
  if(!DataSource.isAllowed(u)){status="数据源地址无效";render();return;}
  requestRunning=true;
  new Thread(()->{
   JSONObject result=null;String error=null;HttpURLConnection c=null;
   try{
    c=(HttpURLConnection)new URL(u).openConnection();connection=c;
    c.setConnectTimeout(4000);c.setReadTimeout(6000);c.setUseCaches(false);
    c.setRequestProperty("Authorization","Bearer "+key);c.setInstanceFollowRedirects(false);
    int code=c.getResponseCode();
    if(code!=200)throw new IOException(code==401?"配对密钥不正确":"数据服务返回 "+code);
    StringBuilder s=new StringBuilder();
    try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"))){String line;while((line=r.readLine())!=null){s.append(line);if(s.length()>100000)throw new IOException("数据响应异常");}}
    result=new JSONObject(s.toString());
   }catch(Exception e){error=e.getMessage();}
   finally{if(c!=null)c.disconnect();connection=null;}
   final JSONObject fresh=result;final String why=error;
   handler.post(()->{
    requestRunning=false;if(!alive)return;
    if(fresh!=null){failures=0;data=fresh;status=fresh.optString("status","已连接数据源");getSharedPreferences("config",0).edit().putString("lastData",fresh.toString()).apply();}
    else{failures++;status="配对密钥不正确".equals(why)?why:(failures<3?"正在重连 · 上次数据":"本地服务未响应 · 请检查 Termux");}
    render();
    handler.removeCallbacks(poll);
    handler.postDelayed(poll,fresh!=null?15000L:Math.min(15000L,2000L*(1L<<Math.min(failures-1,3))));
   });
  },"dragon-quota").start();
 }};
 public int onStartCommand(Intent i,int f,int id){
  if(i!=null&&"stop".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}
  handler.removeCallbacks(poll);if(!requestRunning)handler.post(poll);
  return START_STICKY;
 }
 public void onConfigurationChanged(android.content.res.Configuration c){super.onConfigurationChanged(c);clampPosition();if(root!=null)wm.updateViewLayout(root,lp);positionBubble();}
 public void onDestroy(){
  alive=false;if(modeAnimator!=null)modeAnimator.cancel();if(pet!=null)pet.release();handler.removeCallbacksAndMessages(null);Choreographer.getInstance().removeFrameCallback(motionFrame);
  HttpURLConnection c=connection;if(c!=null)c.disconnect();
  hideBubble();if(root!=null)try{wm.removeView(root);}catch(RuntimeException ignored){}
  stopForeground(true);super.onDestroy();
 }
}
