package dev.sakatourin.dragon;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.graphics.Color;import android.view.*;import android.widget.*;
public class MainActivity extends Activity {
 EditText url,key; public void onCreate(Bundle b){super.onCreate(b);LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(32,48,32,24);l.setBackgroundColor(Color.rgb(248,246,252));setContentView(l);
 TextView t=new TextView(this);t.setText("SaKaTouRin\n正面悬浮角色 · 右上白色气泡");t.setTextSize(24);l.addView(t);
 TextView hint=new TextView(this);hint.setText("点击：五小时 → 本周 → 累计 Token → 收起\n拖动角色移动；长按角色退出。\n首版手动开启悬浮窗。账号数据未连接时显示未连接。\n下方填写你自己的 HTTPS 数据服务，不要填写 OpenAI 密码。");l.addView(hint);
 url=new EditText(this);url.setSingleLine();url.setHint("HTTPS 数据服务地址（可暂时留空）");url.setText(getSharedPreferences("config",0).getString("url",""));l.addView(url);
 key=new EditText(this);key.setSingleLine();key.setHint("你自建服务的访问密钥");key.setInputType(129);key.setText(getSharedPreferences("config",0).getString("key",""));l.addView(key);
 Button save=new Button(this);save.setText("保存数据源");l.addView(save);save.setOnClickListener(v->{String u=url.getText().toString().trim();if(!u.isEmpty()&&!u.startsWith("https://")){Toast.makeText(this,"仅支持 HTTPS",0).show();return;}getSharedPreferences("config",0).edit().putString("url",u).putString("key",key.getText().toString()).apply();Toast.makeText(this,"已保存",0).show();});
 Button permission=new Button(this);permission.setText("① 允许显示悬浮窗");l.addView(permission);permission.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()))));
 Button start=new Button(this);start.setText("② 显示龙娘");l.addView(start);start.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"请先允许悬浮窗权限",0).show();return;}startForegroundService(new Intent(this,DragonService.class));});
 Button stop=new Button(this);stop.setText("隐藏龙娘");l.addView(stop);stop.setOnClickListener(v->stopService(new Intent(this,DragonService.class)));
 }
}
