#!/usr/bin/env python3
"""Local Codex statistics bridge. Run inside the logged-in Debian environment."""
import datetime
import hmac
import json
import math
import os
from pathlib import Path
import queue
import secrets
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = 8765


class RPC:
    def __init__(self):
        self.proc = subprocess.Popen(
            ["codex", "app-server"], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            text=True, bufsize=1)
        self.responses = queue.Queue()
        self.seq = 0
        threading.Thread(target=self.listen, daemon=True).start()
        try:
            self.call("initialize", {"clientInfo": {
                "name": "sakatourin_widget", "version": "0.3"}})
            self.send({"method": "initialized"})
        except Exception:
            self.close()
            raise

    def listen(self):
        for line in self.proc.stdout:
            try:
                self.responses.put(json.loads(line))
            except ValueError:
                continue
        self.responses.put(None)

    def send(self, message):
        self.proc.stdin.write(json.dumps(message) + "\n")
        self.proc.stdin.flush()

    def call(self, method, params=None):
        self.seq += 1
        request_id = self.seq
        self.send({"id": request_id, "method": method, "params": params or {}})
        deadline = time.monotonic() + 40
        while True:
            wait = deadline - time.monotonic()
            if wait <= 0:
                raise TimeoutError("Codex 请求超时")
            message = self.responses.get(timeout=wait)
            if message is None:
                raise RuntimeError("Codex 读取程序退出")
            if message.get("id") == request_id:
                if "error" in message:
                    raise RuntimeError("官方统计接口暂不可用")
                return message["result"]

    def close(self):
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait()
        self.proc.stdout.close()
        self.proc.stdin.close()


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def normalize(result):
    buckets = result.get("rateLimitsByLimitId") or {}
    bucket = buckets.get("codex") or result.get("rateLimits") or {}
    # Never combine unrelated model buckets or assume primary means five hours.
    if bucket.get("limitId") not in (None, "codex"):
        bucket = {}
    output = {"fiveHour": None, "weekly": None}
    for field in ("primary", "secondary"):
        window = bucket.get(field) or {}
        minutes = window.get("windowDurationMins")
        target = {300: "fiveHour", 10080: "weekly"}.get(minutes)
        used = window.get("usedPercent")
        if target and number(used):
            reset = window.get("resetsAt")
            label = "官方暂未返回重置时间"
            if number(reset):
                try:
                    label = "重置 " + datetime.datetime.fromtimestamp(reset).strftime("%m-%d %H:%M")
                except (ValueError, OSError, OverflowError):
                    pass
            output[target] = {"remainingPercent": max(0, min(100, 100-used)),
                              "resetText": label, "resetsAt": reset}
    return output


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.data = {"source": "Codex 官方统计", "status": "正在读取账号额度",
                     "fiveHour": None, "weekly": None, "lifetimeTokens": None,
                     "lastUpdated": None, "stale": False}

    def poll(self):
        rpc = None
        token_time = 0
        tokens = None
        while not self.stop.is_set():
            try:
                if rpc is None:
                    rpc = RPC()
                windows = normalize(rpc.call("account/rateLimits/read"))
                if time.monotonic() - token_time >= 600:
                    try:
                        usage = rpc.call("account/usage/read")
                        value = (usage.get("summary") or {}).get("lifetimeTokens")
                        tokens = int(value) if number(value) and value >= 0 else None
                    except Exception:
                        tokens = None
                    token_time = time.monotonic()
                stamp = int(time.time())
                with self.lock:
                    self.data.update(windows, lifetimeTokens=tokens, lastUpdated=stamp,
                                     stale=False, status="Codex · 更新于 " + time.strftime("%H:%M", time.localtime(stamp)))
            except Exception:
                with self.lock:
                    self.data.update(stale=True, status="刷新失败 · 上次数据" if self.data["lastUpdated"] else "无法读取，请检查 Codex 登录与网络")
                if rpc:
                    rpc.close()
                rpc = None
            if self.stop.wait(60):
                break
        if rpc:
            rpc.close()


def make_handler(state, key):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            if self.path != "/quota":
                self.send_error(404)
                return
            expected = "Bearer " + key
            supplied = self.headers.get("Authorization", "")
            if not hmac.compare_digest(supplied.encode(), expected.encode()):
                self.send_error(401)
                return
            with state.lock:
                body = json.dumps(state.data, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
    return Handler


def main():
    config = Path.home() / ".sakatourin-widget"
    config.mkdir(mode=0o700, exist_ok=True)
    key_path = config / "pairing_key"
    if not key_path.exists():
        with os.fdopen(os.open(key_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as f:
            f.write(secrets.token_hex(8))
    key = key_path.read_text().strip()
    if len(key) != 16:
        raise RuntimeError("配对密钥格式异常")
    state = State()
    server = ThreadingHTTPServer(("127.0.0.1", PORT), make_handler(state, key))
    server.daemon_threads = True
    worker = threading.Thread(target=state.poll, daemon=True)
    worker.start()
    print("\nSaKaTouRin 本地读取服务已启动", flush=True)
    print("数据源：http://127.0.0.1:8765/quota", flush=True)
    print("配对密钥：" + key, flush=True)
    print("将上面两项填入 SaKaTouRin 并保存。保持此窗口运行；Ctrl+C 停止。", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        state.stop.set()
        worker.join(timeout=45)


if __name__ == "__main__":
    main()
