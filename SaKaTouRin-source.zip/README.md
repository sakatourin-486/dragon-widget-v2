# SaKaTouRin 0.3 本地额度连接版

保留 0.2 已确认的 HTML 动画。新增 Termux/Debian 本地统计桥接，累计 Token 使用两位小数中文单位（2.00亿、123.45万），数据来自官方 Codex account/rateLimits/read 与 account/usage/read。仅标记返回的 Codex 统计范围，不声称覆盖全部普通聊天。缺失值显示暂无数据。

## 使用

1. 在已登录 Codex 的 Debian 内运行 quota_bridge.py。无需额外 Python 库。
2. 保持该窗口运行。在安卓 App 填入 http://127.0.0.1:8765/quota 和终端显示的 16 位配对密钥，保存，然后隐藏并重新显示龙娘。
3. 桥接每 60 秒查额度、每 10 分钟查 Token；App 每 15 秒查本地服务。Ctrl+C 停止服务。重启 Termux 后需重新进入 Debian 并运行脚本。

桥接仅监听 127.0.0.1，访问需要配对密钥。脚本不会打印或传送 Codex 登录凭据。配对密钥存放在 Debian 用户目录 .sakatourin-widget/pairing_key；不应上传该文件或 Codex auth.json 到公开仓库。

已通过模拟官方 RPC 协议、窗口识别、空值、HTTP 配对鉴权和退出清理测试。安卓编译及端到端显示需要 GitHub Actions 与设备安装验证；本地没有安卓 SDK。动画部分的代码保持原样。

## GitHub 打包

将同名 SaKaTouRin-source.zip 上传替换仓库内的旧版即可触发现有工作流。若安装提示签名冲突，需卸载旧版后重装；本地数据源和配对密钥可能需要重新填写。
