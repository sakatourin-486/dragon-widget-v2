package dev.sakatourin.dragon;
import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;

public class DragonService extends Service {
 WindowManager wm;
 WindowManager.LayoutParams lp, bubbleLp;
 FrameLayout root;
 DragonView pet;
 android.animation.ValueAnimator modeAnimator;
 boolean working=false;
 float modeBlend=0;
 TextView bubble;
 FrameLayout bubbleRoot;
 int bubbleX,bubbleY;
 long bubbleStart=-1;
 float bubbleScale=1,bubbleLift=0;
 static final float[] BUBBLE_OFFSETS={0,.72f,1},BUBBLE_SCALE={.88f,1.035f,1},BUBBLE_LIFT={7,-2,0};
 int state=0, failures=0;
 Handler handler=new Handler(Looper.getMainLooper());
 volatile boolean alive=true;
 boolean bubbleAdded=false, requestRunning=false, frameScheduled=false;
 volatile HttpURLConnection connection;
 JSONObject data=new JSONObject();
 String status="未连接账号数据";
 long bounceStart=-1;
 int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 float unit(float n){return n*getResources().getDisplayMetrics().density;}
 public IBinder onBind(Intent i){return null;}

 public void onCreate(){
  super.onCreate();
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
  nm.createNotificationChannel(new NotificationChannel("dragon","龙娘悬浮窗",NotificationManager.IMPORTANCE_LOW));
  PendingIntent pi=PendingIntent.getService(this,1,new Intent(this,DragonService.class).setAction("stop"),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"dragon").setContentTitle("SaKaTouRin运行中")
   .setContentText("点击查看额度，拖动移动，长按切换打字")
   .setSmallIcon(android.R.drawable.ic_dialog_info)
   .addAction(new Notification.Action.Builder(null,"关闭",pi).build()).build();
  startForeground(1,n);
  try {data=new JSONObject(getSharedPreferences("config",0).getString("lastData","{}"));}
  catch(JSONException ignored){}
  if(data.length()>0)status="正在重连 · 上次数据";
  wm=(WindowManager)getSystemService(WINDOW_SERVICE);
  root=new FrameLayout(this);root.setClipChildren(false);
  try{pet=new DragonView(this);}catch(IOException e){stopSelf();return;}
  int width=pet.idleWidth,height=pet.imageHeight,surface=surfaceFor(width);
  root.addView(pet,new FrameLayout.LayoutParams(surface,height));
  pet.setViewport(width,height,(surface-width)*.5f,0);
  // No hidden bubble space belongs to this window. Outside touches reach the app below.
  int flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
  lp=new WindowManager.LayoutParams(surface,height,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);
  lp.gravity=Gravity.TOP|Gravity.LEFT;lp.windowAnimations=0;
  lp.flags|=WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
  android.content.SharedPreferences prefs=getSharedPreferences("config",0);
  int center=prefs.contains("petCenterX")?prefs.getInt("petCenterX",dp(32)+width/2):prefs.getInt("petX",dp(32))+width/2;
  lp.x=center-surface/2;
  lp.y=prefs.getInt("petY",dp(280));
  clampPosition();
  try{wm.addView(root,lp);}catch(RuntimeException e){stopSelf();return;}
  bubble=new TextView(this);bubble.setTextColor(Color.rgb(48,39,65));bubble.setTextSize(13);
  bubble.setIncludeFontPadding(false);bubble.setMinHeight(dp(92));bubble.setPadding(dp(16),dp(16),dp(16),dp(16));
  GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(19));bg.setStroke(dp(1),Color.rgb(238,231,245));bubble.setBackground(bg);
  bubbleRoot=new FrameLayout(this);bubbleRoot.setClipChildren(false);
  bubbleRoot.addView(bubble,new FrameLayout.LayoutParams(dp(200),dp(92)));
  bubbleLp=new WindowManager.LayoutParams(dp(200),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,flags,PixelFormat.TRANSLUCENT);
  bubbleLp.gravity=Gravity.TOP|Gravity.LEFT;bubbleLp.windowAnimations=0;
  bubble.setOnClickListener(v->cycle());
  pet.setOnTouchListener(new View.OnTouchListener(){
   float x,y;int ox,oy;boolean dragged,held;
   final Runnable hold=()->{held=true;toggleWorking();pet.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);};
   public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
    case MotionEvent.ACTION_DOWN:stopPetBounce();x=e.getRawX();y=e.getRawY();ox=lp.x;oy=lp.y;dragged=false;held=false;handler.postDelayed(hold,550);return true;
    case MotionEvent.ACTION_MOVE:
     if(held)return true;
     float dx=e.getRawX()-x,dy=e.getRawY()-y;
     if(Math.abs(dx)+Math.abs(dy)>dp(8)){dragged=true;handler.removeCallbacks(hold);}
     if(dragged){lp.x=ox+(int)dx;lp.y=oy+(int)dy;clampPosition();wm.updateViewLayout(root,lp);positionBubble();}return true;
    case MotionEvent.ACTION_UP:
     handler.removeCallbacks(hold);
     if(dragged)getSharedPreferences("config",0).edit().putInt("petCenterX",lp.x+lp.width/2).putInt("petY",lp.y).apply();
     else if(!held&&alive){v.performClick();cycle();}return true;
    case MotionEvent.ACTION_CANCEL:handler.removeCallbacks(hold);return true;
   }return false;}
  });
  handler.post(poll);
 }
 // Use one stable viewport during the cross-fade, then return to the exact
 // visible width so the touch rectangle stays compact.
 void toggleWorking(){
  working=!working;
  if(modeAnimator!=null)modeAnimator.cancel();
  stopPetBounce();pet.setTyping(false);
  final int center=lp.x+lp.width/2,top=lp.y;
  int width=Math.max(pet.idleWidth,pet.workWidth);
  setPetViewport(center,top,width,pet.imageHeight);
  modeAnimator=android.animation.ValueAnimator.ofFloat(modeBlend,working?1f:0f);
  modeAnimator.setDuration(340);
  modeAnimator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
  modeAnimator.addUpdateListener(a->{if(alive){modeBlend=(float)a.getAnimatedValue();pet.setBlend(modeBlend);}});
  modeAnimator.addListener(new android.animation.AnimatorListenerAdapter(){
   boolean cancelled;
   public void onAnimationCancel(android.animation.Animator a){cancelled=true;}
   public void onAnimationEnd(android.animation.Animator a){
    if(cancelled||!alive)return;
    int finalWidth=pet.widthAt(modeBlend);
    setPetViewport(center,top,finalWidth,pet.imageHeight);
    pet.setTyping(working);positionBubble();
   }
  });
  modeAnimator.start();
 }
 int surfaceFor(int width){return (int)Math.ceil(width*HtmlMotion.max(HtmlMotion.X))+2;}
 void setPetViewport(int center,int y,int width,int height){
  int surface=surfaceFor(width);
  lp.x=center-surface/2;lp.y=y;lp.width=surface;lp.height=height;
  pet.setLayoutParams(new FrameLayout.LayoutParams(surface,height));
  pet.setViewport(width,height,(surface-width)*.5f,0);
  clampPosition();wm.updateViewLayout(root,lp);
 }
 void clampPosition(){
  android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getMetrics(m);
  lp.x=Math.max(0,Math.min(Math.max(0,m.widthPixels-lp.width),lp.x));
  lp.y=Math.max(0,Math.min(Math.max(0,m.heightPixels-lp.height),lp.y));
 }
 void positionBubble(){
  if(!bubbleAdded)return;
  android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getMetrics(m);
  bubble.measure(View.MeasureSpec.makeMeasureSpec(dp(200),View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(m.heightPixels,View.MeasureSpec.AT_MOST));
  int petRight=lp.x+lp.width/2+pet.widthAt(modeBlend)/2;
  bubbleX=Math.max(0,Math.min(Math.max(0,m.widthPixels-dp(200)),petRight-dp(20)));
  int anchorY=lp.y;
  int above=anchorY-bubble.getMeasuredHeight()-dp(6);
  bubbleY=Math.max(0,Math.min(Math.max(0,m.heightPixels-bubble.getMeasuredHeight()),above>=0?above:anchorY+pet.imageHeight+dp(6)));
  layoutBubbleViewport();applyBubbleMotion();
 }
 void showBubble(){
  if(!bubbleAdded){try{wm.addView(bubbleRoot,bubbleLp);bubbleAdded=true;}catch(RuntimeException ignored){return;}}
  positionBubble();
 }
 void hideBubble(){bubbleStart=-1;if(bubbleAdded){try{wm.removeView(bubbleRoot);}catch(RuntimeException ignored){}bubbleAdded=false;}}
 // Animate only inside the existing surface. No WindowManager resize or
 // coordinate update occurs on tap.
 void beginPetBounce(){
  bounceStart=System.nanoTime();
 }
 void applyPetMotion(float sx,float sy,float lift){pet.setMotion(sx,sy,unit(lift));}
 void stopPetBounce(){
  if(bounceStart<0)return;
  bounceStart=-1;pet.setMotion(1,1,0);positionBubble();
 }
 void layoutBubbleViewport(){
  int width=dp(200),height=bubble.getMeasuredHeight();
  int[] box=bubbleStart>=0?HtmlMotion.envelope(width,height,.25f,1f,BUBBLE_SCALE,BUBBLE_SCALE,BUBBLE_LIFT,unit(1)):new int[]{0,0,width,height};
  FrameLayout.LayoutParams child=new FrameLayout.LayoutParams(width,height);
  child.leftMargin=-box[0];child.topMargin=-box[1];bubble.setLayoutParams(child);
  bubbleLp.x=bubbleX+box[0];bubbleLp.y=bubbleY+box[1];bubbleLp.width=box[2];bubbleLp.height=box[3];
  wm.updateViewLayout(bubbleRoot,bubbleLp);
 }
 void applyBubbleMotion(){
  if(!bubbleAdded)return;
  bubble.setPivotX(dp(200)*.25f);bubble.setPivotY(bubble.getMeasuredHeight());
  bubble.setScaleX(bubbleScale);bubble.setScaleY(bubbleScale);bubble.setTranslationY(unit(bubbleLift));
 }
 final Choreographer.FrameCallback motionFrame=new Choreographer.FrameCallback(){public void doFrame(long now){
  frameScheduled=false;if(!alive||pet==null)return;
  if(bounceStart>=0){
   float elapsed=(now-bounceStart)/600000000f;
   if(elapsed<1){
    float q=HtmlMotion.bounceProgress(elapsed);
    applyPetMotion(HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.X),HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.Y),HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.LIFT));
   }else stopPetBounce();
  }
  if(bubbleAdded&&bubbleStart>=0){
   float t=(now-bubbleStart)/280000000f,q=HtmlMotion.bubbleProgress(t);
   bubbleScale=HtmlMotion.sample(q,BUBBLE_OFFSETS,BUBBLE_SCALE);
   bubbleLift=HtmlMotion.sample(q,BUBBLE_OFFSETS,BUBBLE_LIFT);
   bubble.setAlpha(q);applyBubbleMotion();
   if(t>=1){bubbleStart=-1;layoutBubbleViewport();}
  }
  if(bounceStart>=0||bubbleStart>=0)scheduleFrame();
 }};
 void scheduleFrame(){if(!frameScheduled&&alive){frameScheduled=true;Choreographer.getInstance().postFrameCallback(motionFrame);}}
 void cycle(){
  stopPetBounce();
  if(modeAnimator==null||!modeAnimator.isRunning()){
   beginPetBounce();
  }
  state=(state+1)%4;
  if(state!=0){bubbleStart=System.nanoTime();bubbleScale=.88f;bubbleLift=7;bubble.setAlpha(0);}
  else bubbleStart=-1;
  render();scheduleFrame();
 }
 static String formatTokens(long tokens){if(tokens>=100000000L)return String.format(java.util.Locale.ROOT,"%.2f亿",tokens/100000000d);if(tokens>=10000L)return String.format(java.util.Locale.ROOT,"%.2f万",tokens/10000d);return String.format(java.util.Locale.ROOT,"%,d",tokens);}
 void render(){if(state==0){hideBubble();return;}String title=state==1?"五小时额度剩余":state==2?"本周额度剩余":"累计 Token";String value="未连接";String foot=status;if(failures==0&&data.has("lastUpdated")&&!data.isNull("lastUpdated")&&System.currentTimeMillis()/1000-data.optLong("lastUpdated")>150)foot="数据已过期 · "+status;if(data.length()>0){if(state==3){if(!data.isNull("lifetimeTokens"))value=formatTokens(data.optLong("lifetimeTokens"));else value="暂无数据";}else{JSONObject w=data.optJSONObject(state==1?"fiveHour":"weekly");if(w!=null&&!w.isNull("remainingPercent")){value=String.format(java.util.Locale.getDefault(),"%.0f%%",w.optDouble("remainingPercent"));if(!data.optBoolean("stale",false)&&!foot.startsWith("数据已过期")&&!status.startsWith("连接中断")&&!status.startsWith("正在重连")&&!status.startsWith("本地服务")&&!status.equals("配对密钥不正确"))foot="Codex · "+w.optString("resetText",status);}else value="暂无数据";}}android.text.SpannableString text=new android.text.SpannableString(title+"\n"+value+"\n"+foot);
 int valueStart=title.length()+1,footStart=valueStart+value.length()+1;
 text.setSpan(new android.text.style.AbsoluteSizeSpan(13,true),0,title.length(),0);
 text.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(142,125,156)),0,title.length(),0);
 text.setSpan(new android.text.style.AbsoluteSizeSpan(23,true),valueStart,footStart-1,0);
 text.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),valueStart,footStart-1,0);
 text.setSpan(new android.text.style.AbsoluteSizeSpan(11,true),footStart,text.length(),0);
 text.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(156,144,164)),footStart,text.length(),0);
 bubble.setText(text);showBubble();}

 // Schedule after completion; never overlap requests. Reconnect rapidly before backing off.
 final Runnable poll=new Runnable(){public void run(){
  if(!alive||requestRunning)return;
  String u=getSharedPreferences("config",0).getString("url","http://127.0.0.1:8765/quota");
  String key=getSharedPreferences("config",0).getString("key","").trim();
  if(!DataSource.isAllowed(u)){status="数据源地址无效";render();return;}
  requestRunning=true;
  new Thread(()->{
   JSONObject result=null;String error=null;HttpURLConnection c=null;
   try{
    c=(HttpURLConnection)new URL(u).openConnection();connection=c;
    c.setConnectTimeout(4000);c.setReadTimeout(6000);c.setUseCaches(false);
    c.setRequestProperty("Authorization","Bearer "+key);c.setInstanceFollowRedirects(false);
    int code=c.getResponseCode();
    if(code!=200)throw new IOException(code==401?"配对密钥不正确":"数据服务返回 "+code);
    StringBuilder s=new StringBuilder();
    try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"))){String line;while((line=r.readLine())!=null){s.append(line);if(s.length()>100000)throw new IOException("数据响应异常");}}
    result=new JSONObject(s.toString());
   }catch(Exception e){error=e.getMessage();}
   finally{if(c!=null)c.disconnect();connection=null;}
   final JSONObject fresh=result;final String why=error;
   handler.post(()->{
    requestRunning=false;if(!alive)return;
    if(fresh!=null){failures=0;data=fresh;status=fresh.optString("status","已连接数据源");getSharedPreferences("config",0).edit().putString("lastData",fresh.toString()).apply();}
    else{failures++;status="配对密钥不正确".equals(why)?why:(failures<3?"正在重连 · 上次数据":"本地服务未响应 · 请检查 Termux");}
    render();
    handler.removeCallbacks(poll);
    handler.postDelayed(poll,fresh!=null?15000L:Math.min(15000L,2000L*(1L<<Math.min(failures-1,3))));
   });
  },"dragon-quota").start();
 }};
 public int onStartCommand(Intent i,int f,int id){
  if(i!=null&&"stop".equals(i.getAction())){stopSelf();return START_NOT_STICKY;}
  handler.removeCallbacks(poll);if(!requestRunning)handler.post(poll);
  return START_STICKY;
 }
 public void onConfigurationChanged(android.content.res.Configuration c){super.onConfigurationChanged(c);clampPosition();if(root!=null)wm.updateViewLayout(root,lp);positionBubble();}
 public void onDestroy(){
  alive=false;if(modeAnimator!=null)modeAnimator.cancel();if(pet!=null)pet.release();handler.removeCallbacksAndMessages(null);Choreographer.getInstance().removeFrameCallback(motionFrame);
  HttpURLConnection c=connection;if(c!=null)c.disconnect();
  hideBubble();if(root!=null)try{wm.removeView(root);}catch(RuntimeException ignored){}
  stopForeground(true);super.onDestroy();
 }
}
