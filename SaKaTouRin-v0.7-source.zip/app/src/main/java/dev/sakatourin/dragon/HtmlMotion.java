package dev.sakatourin.dragon;

/** The preview's CSS timing, in logical pixels and milliseconds. */
final class HtmlMotion {
    static final float[] OFFSETS = {0f, .16f, .40f, .65f, .82f, 1f};
    static final float[] X = {1f, 1.10f, .93f, 1.05f, .99f, 1f};
    static final float[] LIFT = {0f, 0f, 0f, 0f, 0f, 0f};
    static final float[] Y = {1f, .84f, 1.09f, .93f, 1.025f, 1f};
    /** Smallest integer window containing the transformed child. */
    static int[] bounds(int w,int h,float pivotX,float pivotY,float sx,float sy,float dy) {
        float x=w*pivotX*(1-sx),y=h*pivotY*(1-sy)+dy;
        int left=(int)Math.floor(x),top=(int)Math.floor(y);
        return new int[]{left,top,(int)Math.ceil(x+w*sx)-left,(int)Math.ceil(y+h*sy)-top};
    }
    static int[] envelope(int w,int h,float px,float py,float[] sx,float[] sy,float[] lift,float unit){
        int left=0,top=0,right=w,bottom=h;
        for(int i=0;i<sx.length;i++){
            int[] b=bounds(w,h,px,py,sx[i],sy[i],lift[i]*unit);
            left=Math.min(left,b[0]);top=Math.min(top,b[1]);
            right=Math.max(right,b[0]+b[2]);bottom=Math.max(bottom,b[1]+b[3]);
        }
        return new int[]{left,top,right-left,bottom-top};
    }
    static float sample(float p, float[] offsets, float[] values) {
        p = Math.max(0f, Math.min(1f, p));
        for (int i = 1; i < offsets.length; i++) {
            if (p <= offsets[i]) {
                float t = (p - offsets[i-1]) / (offsets[i] - offsets[i-1]);
                return values[i-1] + (values[i] - values[i-1]) * t;
            }
        }
        return values[values.length-1];
    }
    static double cubic(double t, double a, double b) {
        double u = 1 - t;
        return 3*u*u*t*a + 3*u*t*t*b + t*t*t;
    }
    static float ease(float progress, double x1, double y1, double x2, double y2) {
        if (progress <= 0) return 0;
        if (progress >= 1) return 1;
        double lo = 0, hi = 1;
        for (int i = 0; i < 30; i++) {
            double t = (lo + hi) / 2;
            if (cubic(t, x1, x2) < progress) lo = t; else hi = t;
        }
        return (float)cubic((lo+hi)/2, y1, y2);
    }
    static float bounceProgress(float progress) { return ease(progress, .2, .65, .3, 1); }
    static float bubbleProgress(float progress) { return ease(progress, 0, 0, .58, 1); }
}
