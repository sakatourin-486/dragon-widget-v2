package dev.sakatourin.dragon;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.view.animation.*;import android.widget.*;import org.json.*;import java.net.*;import java.io.*;
public class DragonService extends Service {
 WindowManager wm;WindowManager.LayoutParams lp;android.widget.FrameLayout root;TextView bubble;int state=0;Handler handler=new Handler();boolean alive=true;JSONObject data=new JSONObject();String status="未连接账号数据";
 int dp(float n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}public IBinder onBind(Intent i){return null;}
 public void onCreate(){super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("dragon","龙娘悬浮窗",NotificationManager.IMPORTANCE_LOW));Intent close=new Intent(this,DragonService.class).setAction("stop");PendingIntent pi=PendingIntent.getService(this,1,close,PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(this,"dragon").setContentTitle("SaKaTouRin运行中").setContentText("点击龙娘切换额度，长按退出").setSmallIcon(android.R.drawable.ic_dialog_info).addAction(new Notification.Action.Builder(null,"关闭",pi).build()).build();startForeground(1,n);
 wm=(WindowManager)getSystemService(WINDOW_SERVICE);root=new FrameLayout(this);root.setClipChildren(false);ImageView pet=new ImageView(this);try{pet.setImageDrawable(Drawable.createFromStream(getAssets().open("dragon.png"),null));}catch(Exception e){}pet.setScaleType(ImageView.ScaleType.FIT_CENTER);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(150),dp(195));pp.topMargin=dp(95);root.addView(pet,pp);
 bubble=new TextView(this);bubble.setTextColor(Color.rgb(48,39,65));bubble.setTextSize(13);bubble.setIncludeFontPadding(false);bubble.setMinHeight(dp(92));bubble.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(19));bg.setStroke(dp(1),Color.rgb(238,231,245));bubble.setBackground(bg);bubble.setElevation(dp(5));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(200),ViewGroup.LayoutParams.WRAP_CONTENT);bp.leftMargin=dp(70);bp.topMargin=0;root.addView(bubble,bp);bubble.setVisibility(View.GONE);bubble.setOnClickListener(v->cycle());
 lp=new WindowManager.LayoutParams(dp(280),dp(310),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.LEFT;lp.x=dp(12);lp.y=dp(160);try{wm.addView(root,lp);}catch(Exception e){stopSelf();return;}
 pet.setOnTouchListener(new View.OnTouchListener(){float x,y;int ox,oy;boolean dragged;Runnable hold=()->stopSelf();public boolean onTouch(View v,android.view.MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:x=e.getRawX();y=e.getRawY();ox=lp.x;oy=lp.y;dragged=false;handler.postDelayed(hold,800);return true;case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-x,dy=e.getRawY()-y;if(Math.abs(dx)+Math.abs(dy)>dp(8)){dragged=true;handler.removeCallbacks(hold);}if(dragged){android.util.DisplayMetrics m=new android.util.DisplayMetrics();wm.getDefaultDisplay().getMetrics(m);lp.x=Math.max(0,Math.min(m.widthPixels-lp.width,ox+(int)dx));lp.y=Math.max(0,Math.min(m.heightPixels-lp.height,oy+(int)dy));wm.updateViewLayout(root,lp);}return true;case MotionEvent.ACTION_UP:handler.removeCallbacks(hold);if(!dragged&&alive)cycle();return true;case MotionEvent.ACTION_CANCEL:handler.removeCallbacks(hold);return true;}return false;}});
 motionEpoch=System.nanoTime();Choreographer.getInstance().postFrameCallback(motionFrame);handler.post(poll);
 }
 static final float[] BUBBLE_OFFSETS={0,.72f,1},BUBBLE_SCALE={.88f,1.035f,1},BUBBLE_LIFT={7,-2,0};
 long motionEpoch, bounceStart=-1, bubbleStart=-1;
 float unit(float n){return n*getResources().getDisplayMetrics().density;}
 final Choreographer.FrameCallback motionFrame=new Choreographer.FrameCallback(){
  public void doFrame(long now){
   if(!alive||root==null)return;
   View pet=root.getChildAt(0);
   pet.setPivotX(pet.getWidth()*.5f);pet.setPivotY(pet.getHeight()*.94f);
   float sx=1,sy=1,lift=HtmlMotion.breathe(((now-motionEpoch)%3000000000L)/3000000000f);
   if(bounceStart>=0){
    float elapsed=(now-bounceStart)/600000000f;
    if(elapsed<1){float q=HtmlMotion.bounceProgress(elapsed);sx=HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.X);sy=HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.Y);lift=HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.LIFT);}
    else bounceStart=-1;
   }
   pet.setScaleX(sx);pet.setScaleY(sy);pet.setTranslationY(unit(lift));
   if(state!=0&&bubbleStart>=0){
    float t=(now-bubbleStart)/280000000f;
    float q=HtmlMotion.bubbleProgress(t);
    float scale=HtmlMotion.sample(q,BUBBLE_OFFSETS,BUBBLE_SCALE);
    bubble.setPivotX(bubble.getWidth()*.25f);bubble.setPivotY(bubble.getHeight());
    bubble.setScaleX(scale);bubble.setScaleY(scale);
    bubble.setAlpha(q);bubble.setTranslationY(unit(HtmlMotion.sample(q,BUBBLE_OFFSETS,BUBBLE_LIFT)));
    if(t>=1)bubbleStart=-1;
   }
   Choreographer.getInstance().postFrameCallback(this);
  }
 };
 void bounce(){bounceStart=System.nanoTime();}
 void cycle(){bounce();state=(state+1)%4;render();if(state!=0){bubbleStart=System.nanoTime();bubble.setAlpha(0);bubble.setScaleX(.88f);bubble.setScaleY(.88f);bubble.setTranslationY(unit(7));}else bubbleStart=-1;}
 void render(){if(state==0){bubble.setVisibility(View.GONE);return;}String title=state==1?"五小时额度剩余":state==2?"本周额度剩余":"累计 Token";String value="未连接";String foot=status;if(data.length()>0){if(state==3){if(!data.isNull("lifetimeTokens"))value=String.format(java.util.Locale.getDefault(),"%,d",data.optLong("lifetimeTokens"));else value="暂无数据";}else{JSONObject w=data.optJSONObject(state==1?"fiveHour":"weekly");if(w!=null&&!w.isNull("remainingPercent")){value=String.format(java.util.Locale.getDefault(),"%.0f%%",w.optDouble("remainingPercent"));foot=w.optString("resetText",status);}else value="暂无数据";}}android.text.SpannableString text=new android.text.SpannableString(title+"\n"+value+"\n"+foot);
 int valueStart=title.length()+1,footStart=valueStart+value.length()+1;
 text.setSpan(new android.text.style.AbsoluteSizeSpan(13,true),0,title.length(),0);
 text.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(142,125,156)),0,title.length(),0);
 text.setSpan(new android.text.style.AbsoluteSizeSpan(23,true),valueStart,footStart-1,0);
 text.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD),valueStart,footStart-1,0);
 text.setSpan(new android.text.style.AbsoluteSizeSpan(11,true),footStart,text.length(),0);
 text.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(156,144,164)),footStart,text.length(),0);
 bubble.setText(text);bubble.setVisibility(View.VISIBLE);}
 Runnable poll=new Runnable(){public void run(){String u=getSharedPreferences("config",0).getString("url","");String k=getSharedPreferences("config",0).getString("key","");if(u.startsWith("https://"))new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setRequestProperty("Authorization","Bearer "+k);c.setInstanceFollowRedirects(false);if(c.getResponseCode()!=200)throw new IOException();StringBuilder s=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()))){String line;while((line=r.readLine())!=null){s.append(line);if(s.length()>100000)throw new IOException();}}c.disconnect();JSONObject j=new JSONObject(s.toString());handler.post(()->{if(!alive)return;data=j;status="更新于 "+new java.text.SimpleDateFormat("HH:mm",java.util.Locale.getDefault()).format(new java.util.Date());render();});}catch(Exception e){handler.post(()->{if(!alive)return;status=data.length()>0?"刷新失败 · 上次数据":"连接失败";render();});}}).start();handler.postDelayed(this,60000);}};
 public int onStartCommand(Intent i,int f,int id){if(i!=null&&"stop".equals(i.getAction()))stopSelf();return START_NOT_STICKY;}
 public void onDestroy(){alive=false;Choreographer.getInstance().removeFrameCallback(motionFrame);handler.removeCallbacksAndMessages(null);if(root!=null){View pet=root.getChildAt(0);try{wm.removeView(root);}catch(Exception e){}}stopForeground(true);super.onDestroy();}
}
