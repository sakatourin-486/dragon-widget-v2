# SaKaTouRin

0.2：安卓动画按随包 HTML 预览对齐。600ms、相同关键帧时间点及 cubic-bezier；280ms 气泡弹出；3000ms 待机浮动。采用屏幕逐帧回调，连续点击重新开始，退出释放回调。保留应用名称与 sktr 图标。

已对比 601 个时间点的动画曲线数值。尚需 GitHub Actions 编译与安卓实机确认。额度数据仍未连接。

# SaKaTouRin 应用图标与名称更新

应用名称为 SaKaTouRin。应用图标使用用户提供的白底黑色 sktr 原图，已配置自适应图标。保留首次 Q 弹点击动画，不包含后续 tapBounce 逐帧补丁。

本压缩包为源码，不是 APK。真实额度尚未接通。若从仓库根目录 ZIP 自动解压编译，workflow 的 ZIP 文件名应改为实际上传的文件名。不要加入之前的“修复点击弹跳”步骤。

# SaKaTouRin 0.1

安卓原生悬浮窗源码，前视白发龙娘，右上白色气泡。

## 当前完成与限制

- 已编写：悬浮窗、拖动、点击切换五小时/本周/累计 Token/隐藏，长按关闭，常驻通知关闭按钮，轻微上下浮动。
- 初版需手动启动，不会检测 ChatGPT 是否打开；关闭后不会自行恢复。
- 未配置数据服务时只显示“未连接”，不使用模拟额度。
- 数据接入：每 60 秒读取自建 HTTPS 服务；本项目未实现 OpenAI OAuth 或 Codex app-server 桥接。不能只填 OpenAI API Key 就读取 Plus 额度。
- 当前环境缺 Android SDK 和 Gradle，尚未编译或真机测试。源码不能当作 APK 安装。
- targetSdk 32 用于个人侧载原型，不适合直接提交当前 Google Play。后续正式分发需升级前台服务及通知权限适配。
- 原图经图像生成工具提取重绘为透明前视素材；目前动画仅为整体轻微浮动，无独立眨眼、摆尾。

## 安卓平板体验

打开单文件 `龙娘交互预览.html`，点击和拖动角色即可体验。该预览仅在网页内运行，不能盖在 ChatGPT App 上；真实跨应用悬浮需要安装 APK。

## 仅用平板在 GitHub 云端打包

1. 在自己的 GitHub 创建仓库。使用浏览器上传本目录里的文件与 app 文件夹，保持路径。
2. 注意 `.github/workflows/build.yml` 是隐藏目录下的构建文件。若上传界面漏掉，用 GitHub 的 Add file → Create new file 创建该路径并粘贴内容。
3. 在仓库 Actions 中运行 Build Android APK。编译工具与依赖需要 GitHub runner 访问网络，首次构建可能需几分钟。
4. 构建成功后下载 DragonQuota-APK artifact，解压，安装 app-debug.apk。
5. 打开“SaKaTouRin”，允许“显示在其他应用上层”，点击“显示龙娘”。可按平板系统需要允许后台运行。

GitHub Actions 文件已提供，但尚未在账号中运行，不能保证首次构建通过。

## 数据服务契约

应用向所填 HTTPS 地址 GET，携带 Authorization: Bearer <你自建服务的密钥>。

返回 JSON：
```json
{
  "fiveHour": {"remainingPercent": 68, "resetText": "约 2 小时后恢复"},
  "weekly": {"remainingPercent": 42, "resetText": "周日恢复"},
  "lifetimeTokens": 1234567
}
```
上面数字只解释格式，未放入应用默认数据。没有数据应返回 null。

官方可研究接口为 Codex app-server 的 account/rateLimits/read 和 account/usage/read，需用户登录验证。文档：https://learn.chatgpt.com/docs/app-server 。累计 Token 的统计范围须核对，不承诺覆盖普通聊天、Work、API 全部产品。

本原型不会向任何默认服务器发送账号或密钥；数据源由用户自行配置，Android 私有存储不等同于硬件加密密钥库。不要把 OpenAI 密码粘到配置栏。
