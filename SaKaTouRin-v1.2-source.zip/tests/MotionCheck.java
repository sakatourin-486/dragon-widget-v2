package dev.sakatourin.dragon;
public class MotionCheck {
 static void check(int w,int h,float px,float py,float sx,float sy,float dy){
  int[] b=HtmlMotion.bounds(w,h,px,py,sx,sy,dy);
  for(int x:new int[]{0,w})for(int y:new int[]{0,h}){
   float xx=w*px+(x-w*px)*sx-b[0], yy=h*py+(y-h*py)*sy+dy-b[1];
   if(xx < -.001 || yy < -.001 || xx > b[2]+.001 || yy > b[3]+.001)throw new AssertionError("Clipped");
  }
 }
 public static void main(String[] args){
  for(int w:new int[]{111,137,333,411})for(int i=0;i<=1000;i++){
   float q=HtmlMotion.bounceProgress(i/1000f);
   float sx=HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.X),sy=HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.Y),dy=3*HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.LIFT);
   if(Math.abs(435+(435-435)*sy+dy-435)>.001f)throw new AssertionError("Feet moved vertically");
   if(sy>1.00001f)throw new AssertionError("Character rose above resting height");
   int surface=(int)Math.ceil(w*HtmlMotion.max(HtmlMotion.X))+2;
   float padding=(surface-w)*.5f;
   int[] actual=HtmlMotion.bounds(w,435,.5f,1f,sx,sy,dy);
   if(padding+actual[0]<-.001f||padding+actual[0]+actual[2]>surface+.001f||actual[1]<0||actual[1]+actual[3]>435)throw new AssertionError("Outside fixed surface");
   check(w,435,.5f,1f,HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.X),HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.Y),3*HtmlMotion.sample(q,HtmlMotion.OFFSETS,HtmlMotion.LIFT));
   float z=HtmlMotion.bubbleProgress(i/1000f),s=HtmlMotion.sample(z,new float[]{0,.72f,1},new float[]{.88f,1.035f,1});
   check(600,276,.25f,1,s,s,3*HtmlMotion.sample(z,new float[]{0,.72f,1},new float[]{7,-2,0}));
  }
  int[] b=HtmlMotion.bounds(111,145,.5f,1f,1,1,0);
  if(b[0]!=0||b[1]!=0||b[2]!=111||b[3]!=145)throw new AssertionError("Idle padding");
  if(!HtmlMotion.bubbleEntrance(0,1))throw new AssertionError("Missing first entrance");
  if(HtmlMotion.bubbleEntrance(1,2)||HtmlMotion.bubbleEntrance(2,3)||HtmlMotion.bubbleEntrance(3,0))throw new AssertionError("Bubble would flash while cycling");
  System.out.println("Fixed-surface bounce: no native movement, no rise above rest, feet remain fixed.");
 }
}
